from django.apps import AppConfig


class ThirdConfig(AppConfig):
    name = 'third'
